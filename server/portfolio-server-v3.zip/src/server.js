import "dotenv/config";
import express from "express";
import cors from "cors";
import analyticsRoutes from "./routes/analytics.routes.js";

const app = express();

app.set("trust proxy", true);


const allowedOrigins = [
  process.env.CLIENT_ORIGIN, 
  "http://localhost:5173",
].filter(Boolean);

app.use(
  cors({
    origin: (origin, cb) => {
      // allow non-browser tools (curl/postman/health checks)
      if (!origin) return cb(null, true);

      if (allowedOrigins.includes(origin)) return cb(null, true);

      return cb(null, false);
    },
    credentials: true,
    methods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);


app.options("*", cors());

app.use(express.json());
app.use("/api/analytics", analyticsRoutes);
app.get("/api/dbcheck", async (_req, res) => {
  try {
    const [rows] = await pool.query("SELECT 1 as ok");
    res.json({ ok: true, rows });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});
app.get("/api/health", (_req, res) => res.json({ ok: true }));

const port = Number(process.env.PORT || 3001);
app.listen(port, () => {
  console.log(`✅ Portfolio API running at http://localhost:${port}`);
});
