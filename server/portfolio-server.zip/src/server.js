import "dotenv/config";
import express from "express";
import cors from "cors";
import analyticsRoutes from "./routes/analytics.routes.js";


const app = express();


app.set("trust proxy", true); // important when deployed behind a proxy
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use("/api/analytics", analyticsRoutes);

app.get("/api/health", (_req, res) => res.json({ ok: true }));

const port = Number(process.env.PORT || 3001);
app.listen(port, () => {
  console.log(`✅ Portfolio API running at http://localhost:${port}`);
});
